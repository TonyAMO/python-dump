def main():
    print("Hello World!")
    second()
def second():
    name = "Tony"
    age = 21 + 3
    print("I am {}!".format(name), f"I am {float(age)} years old!")
    name = "Antonio"
    print(f"Now I'm {name}!")
    print(type(name))
    adult = True
    print(type(age))
    print(adult)
    adult = bool(0)
    print(adult)
    print(type(adult))
    age = float(age)
    print(age)
    print(type(age))
    x = 4
    y = 3
    print("x > 2 and y > 1:", x > 2 and y > 1)
    print("x > 5 or y <= 3:", x > 5 or y <= 3)
    print("not(x > 2 and y > 1):", not(x > 2 and y > 1))

if __name__=='__main__':
    main()
